A Pen created at CodePen.io. You can find this one at http://codepen.io/suez/pen/RpNXOR.

 Based on Dribbble shot by Barbara Morrigan - https://dribbble.com/shots/3306190-Login-Registration-form