$(".login").click(function() {
  $("#wrapper").addClass('flip');
});

$(".logout").click(function() {
  $("#wrapper").removeClass('flip');
});