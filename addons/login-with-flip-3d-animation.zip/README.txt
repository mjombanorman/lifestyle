A Pen created at CodePen.io. You can find this one at http://codepen.io/mariusbalaj/pen/Afpay.

 Flat login with cool flip 3d animation. Press the login button